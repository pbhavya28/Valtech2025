package com.valtech.training.jaxwsclien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaxwsclienApplication {

	public static void main(String[] args) {
		SpringApplication.run(JaxwsclienApplication.class, args);
	}

}
